FURNITURE HISAB - ANDROID PROJECT

Brand look: Dark green + white, custom launcher icon.
Main record fields: Photo, Size, Model No., Amount.
Date/day/time are filled automatically and can be edited in the record form.
Automatic total, edit/delete, manual JSON backup/restore (including photos).

BUILD:
1. Android Studio (JDK 17) install karein.
2. ZIP extract karein aur Android Studio mein FurnitureHisab folder open karein.
3. Gradle sync hone dein. Internet required ho sakta hai for first dependency download.
4. Phone connect karke Run karein, ya Build > Generate Signed Bundle / APK se signed release banayein.
5. Play Store ke liye signed Android App Bundle (.aab) banayein; keystore ko safely sambhal kar rakhein.

BACKUP:
Android Auto Backup Android/Google backup settings par depend karta hai; real-time sync nahi hai.
Phone Settings > Google > Backup mein backup enabled rakhein. Manual backup JSON ko Google Drive/computer/another safe place par alag save karein.

PLAY STORE CHECKLIST:
- App ka final package ID, version, signed AAB.
- Public HTTPS privacy policy URL (PRIVACY_POLICY_DRAFT.txt ko review karke host karein).
- Play Console Data safety form, content rating, app access declaration (if applicable).
- Store listing: title, short/full description, icon, screenshots, feature graphic.
- Test app on real devices; verify backup/restore and photo handling before release.
- Google Play Developer account and any current verification/testing requirements.

This is Android Studio source code, not a prebuilt APK/AAB and not yet published. Google Play publication requires the developer account and release review.
