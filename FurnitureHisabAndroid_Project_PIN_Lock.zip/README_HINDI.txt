FURNITURE HISAB - ANDROID PROJECT

Is project ko Android Studio mein kholen.

Build karne ke liye:
1. Android Studio install karein (JDK 17 ke saath).
2. Is ZIP ko extract karein.
3. Android Studio > Open > FurnitureHisab folder select karein.
4. Gradle sync hone dein.
5. USB debugging on karke phone connect karein.
6. Run button dabayein. APK ke liye Build > Build APK(s).

Features:
- App lock: first launch par 4-6 digit PIN set karein; har app launch par PIN required hai\n- App PIN change karne ka option\n- Furniture record add/edit/delete
- Model number, size, amount, date & time
- Automatic total amount
- Gallery se photo select
- Manual JSON backup/restore (photo bhi backup mein include hoti hai)
- Android Auto Backup rules: database aur app ke photo files backup ke liye include hain.

IMPORTANT BACKUP:
Automatic cloud backup Android ke Google Backup system par depend karta hai.
Phone Settings > Google > Backup mein backup enabled rakhein aur wahi Google account
naye phone par use karein. Google/Android backup ka timing aur restore phone settings
aur Android version par depend karta hai; ise real-time sync na samjhein.
Manual backup ko alag jagah (Google Drive ya computer) save karna sabse safe hai.

This is an Android Studio source project, not a prebuilt APK. PIN bhoolne par app data clear/reinstall karne se local records bhi delete ho sakte hain; isliye manual backup safe jagah rakhein.
