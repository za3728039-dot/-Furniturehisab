package com.example.furniturehisab

import android.app.Activity
import android.app.AlertDialog
import android.content.ContentValues
import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper
import android.net.Uri
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.widget.*
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.ComponentActivity
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import android.util.Base64
import java.security.MessageDigest

data class Furniture(
    val id: Long, val model: String, val size: String, val amount: Double,
    val dateTime: String, val photo: String
)

class Db(context: Context) : SQLiteOpenHelper(context, "furniture.db", null, 1) {
    override fun onCreate(db: SQLiteDatabase) {
        db.execSQL("CREATE TABLE items(id INTEGER PRIMARY KEY AUTOINCREMENT, model TEXT, size TEXT, amount REAL, dateTime TEXT, photo TEXT)")
    }
    override fun onUpgrade(db: SQLiteDatabase, oldVersion: Int, newVersion: Int) {}
    fun all(): List<Furniture> {
        val out = mutableListOf<Furniture>()
        readableDatabase.rawQuery("SELECT * FROM items ORDER BY id DESC", null).use { c ->
            while (c.moveToNext()) out.add(Furniture(c.getLong(0), c.getString(1) ?: "", c.getString(2) ?: "",
                c.getDouble(3), c.getString(4) ?: "", c.getString(5) ?: ""))
        }
        return out
    }
    fun save(id: Long?, model: String, size: String, amount: Double, date: String, photo: String) {
        val v = ContentValues().apply {
            put("model", model); put("size", size); put("amount", amount); put("dateTime", date); put("photo", photo)
        }
        if (id == null) writableDatabase.insert("items", null, v)
        else writableDatabase.update("items", v, "id=?", arrayOf(id.toString()))
    }
    fun delete(id: Long) { writableDatabase.delete("items", "id=?", arrayOf(id.toString())) }
    fun clear() { writableDatabase.delete("items", null, null) }
}

class MainActivity : ComponentActivity() {
    private lateinit var db: Db
    private lateinit var root: LinearLayout
    private var chosenPhoto = ""
    private var photoLabel: TextView? = null
    private var pendingPhotoTarget: String? = null

    private val pickPhoto = registerForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        if (uri != null) {
            val dest = File(filesDir, "photo_${System.currentTimeMillis()}.jpg")
            contentResolver.openInputStream(uri)?.use { input -> dest.outputStream().use { input.copyTo(it) } }
            chosenPhoto = dest.absolutePath
            photoLabel?.text = "Photo selected ✓"
        }
    }
    private val exportBackup = registerForActivityResult(ActivityResultContracts.CreateDocument("application/json")) { uri ->
        if (uri != null) try { contentResolver.openOutputStream(uri)?.bufferedWriter()?.use { it.write(makeBackup().toString(2)) }; toast("Backup saved") } catch (e: Exception) { toast("Backup failed") }
    }
    private val importBackup = registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) try {
            val text = contentResolver.openInputStream(uri)?.bufferedReader()?.use { it.readText() } ?: ""
            restoreBackup(JSONObject(text)); refresh(); toast("Backup restored")
        } catch (e: Exception) { toast("Backup file is not valid") }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        db = Db(this)
        root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(28, 24, 28, 20); setBackgroundColor(0xFFF7F7F7.toInt()) }
        setContentView(root)
        showPinGate()
    }

    // App lock: first launch asks the owner to create a 4-6 digit PIN.
    // The PIN is stored as a SHA-256 hash in private app preferences.
    private fun pinHash(pin: String): String {
        val bytes = MessageDigest.getInstance("SHA-256").digest(pin.toByteArray(Charsets.UTF_8))
        return bytes.joinToString("") { "%02x".format(it) }
    }

    private fun showPinGate() {
        val prefs = getSharedPreferences("app_lock", MODE_PRIVATE)
        val savedHash = prefs.getString("pin_hash", null)
        val input = EditText(this).apply {
            hint = if (savedHash == null) "Create 4-6 digit PIN" else "Enter app PIN"
            inputType = android.text.InputType.TYPE_CLASS_NUMBER or android.text.InputType.TYPE_NUMBER_VARIATION_PASSWORD
            setSingleLine(true)
        }
        val dialog = AlertDialog.Builder(this)
            .setTitle(if (savedHash == null) "Set App Lock PIN" else "Furniture Hisab Locked")
            .setMessage(if (savedHash == null) "Create a PIN to protect your furniture records." else "Enter your PIN to continue.")
            .setView(input)
            .setCancelable(false)
            .setPositiveButton(if (savedHash == null) "Set PIN" else "Unlock", null)
            .create()
        dialog.setOnShowListener {
            dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener {
                val pin = input.text.toString()
                if (pin.length !in 4..6 || pin.any { !it.isDigit() }) {
                    input.error = "PIN 4 se 6 digits ka hona chahiye"
                    return@setOnClickListener
                }
                if (savedHash == null) {
                    prefs.edit().putString("pin_hash", pinHash(pin)).apply()
                    dialog.dismiss()
                    refresh()
                } else if (pinHash(pin) == savedHash) {
                    dialog.dismiss()
                    refresh()
                } else {
                    input.error = "Wrong PIN. Dobara try karein."
                    input.text.clear()
                }
            }
        }
        dialog.show()
    }

    private fun refresh() {
        root.removeAllViews()
        val title = TextView(this).apply { text = "🪑 Furniture Hisab"; textSize = 25f; setTextColor(0xFF222222.toInt()); gravity = Gravity.CENTER_VERTICAL }
        root.addView(title, lp(-1, 58))
        val records = db.all()
        val total = records.sumOf { it.amount }
        root.addView(TextView(this).apply {
            text = "Total Amount: ₹${money(total)}\nTotal Records: ${records.size}"
            textSize = 19f; setTextColor(0xFF145A32.toInt()); setPadding(16, 18, 16, 18)
            setBackgroundColor(0xFFE4F3E8.toInt())
        }, lp(-1, -2, 10))
        val add = Button(this).apply { text = "+ Add Furniture"; setOnClickListener { showForm(null) } }
        root.addView(add, lp(-1, -2, 6))
        val backupRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        backupRow.addView(Button(this).apply { text = "Save Backup"; setOnClickListener { exportBackup.launch("FurnitureHisabBackup.json") } }, LinearLayout.LayoutParams(0, -2, 1f))
        backupRow.addView(Button(this).apply { text = "Restore Backup"; setOnClickListener { importBackup.launch(arrayOf("application/json", "text/*")) } }, LinearLayout.LayoutParams(0, -2, 1f))
        root.addView(backupRow, lp(-1, -2, 6))
        root.addView(Button(this).apply {
            text = "Change App PIN"
            setOnClickListener { changePin() }
        }, lp(-1, -2, 6))
        val scroll = ScrollView(this)
        val list = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        records.forEach { item ->
            val card = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL; setPadding(16, 12, 16, 12); setBackgroundColor(0xFFFFFFFF.toInt())
            }
            card.addView(TextView(this).apply {
                text = "Model: ${item.model}\nSize: ${item.size}\nAmount: ₹${money(item.amount)}\nDate & Time: ${item.dateTime}" +
                    if (item.photo.isNotBlank()) "\n📷 Photo attached" else ""
                textSize = 16f; setTextColor(0xFF222222.toInt())
            })
            val actions = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
            actions.addView(Button(this).apply { text = "Edit"; setOnClickListener { showForm(item) } }, LinearLayout.LayoutParams(0, -2, 1f))
            actions.addView(Button(this).apply { text = "Delete"; setOnClickListener {
                AlertDialog.Builder(this@MainActivity).setMessage("Delete this record?").setNegativeButton("Cancel", null)
                    .setPositiveButton("Delete") { _, _ -> db.delete(item.id); refresh() }.show()
            } }, LinearLayout.LayoutParams(0, -2, 1f))
            card.addView(actions)
            list.addView(card, lp(-1, -2, 8))
        }
        scroll.addView(list)
        root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))
    }

    private fun showForm(item: Furniture?) {
        chosenPhoto = item?.photo ?: ""
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(24, 8, 24, 4) }
        fun field(hint: String, value: String = ""): EditText {
            val e = EditText(this); e.hint = hint; e.setText(value); box.addView(e, lp(-1, -2, 4)); return e
        }
        val model = field("Model number", item?.model ?: "")
        val size = field("Size (e.g. 6 ft x 3 ft x 2 ft)", item?.size ?: "")
        val amount = field("Amount (₹)", if (item != null) item.amount.toString() else "")
        val date = field("Date & time", item?.dateTime ?: SimpleDateFormat("dd-MM-yyyy, EEEE, hh:mm a", Locale.getDefault()).format(Date()))
        val photoBtn = Button(this).apply { text = "Choose Furniture Photo"; setOnClickListener { photoLabel?.text = "Opening gallery…"; pickPhoto.launch("image/*") } }
        box.addView(photoBtn)
        photoLabel = TextView(this).apply { text = if (chosenPhoto.isNotBlank()) "Photo selected ✓" else "No photo selected" }
        box.addView(photoLabel)
        AlertDialog.Builder(this).setTitle(if (item == null) "Add Furniture" else "Edit Furniture")
            .setView(ScrollView(this).apply { addView(box) })
            .setNegativeButton("Cancel", null)
            .setPositiveButton("Save") { _, _ ->
                val a = amount.text.toString().trim().toDoubleOrNull()
                if (model.text.isBlank() || a == null) { toast("Model number aur valid amount bhariye"); return@setPositiveButton }
                db.save(item?.id, model.text.toString().trim(), size.text.toString().trim(), a,
                    date.text.toString().trim(), chosenPhoto)
                refresh()
            }.show()
    }

    private fun changePin() {
        val prefs = getSharedPreferences("app_lock", MODE_PRIVATE)
        val current = EditText(this).apply {
            hint = "Current PIN"
            inputType = android.text.InputType.TYPE_CLASS_NUMBER or android.text.InputType.TYPE_NUMBER_VARIATION_PASSWORD
        }
        val next = EditText(this).apply {
            hint = "New 4-6 digit PIN"
            inputType = android.text.InputType.TYPE_CLASS_NUMBER or android.text.InputType.TYPE_NUMBER_VARIATION_PASSWORD
        }
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(24, 8, 24, 4)
            addView(current, lp(-1, -2, 6))
            addView(next, lp(-1, -2, 6))
        }
        val dialog = AlertDialog.Builder(this).setTitle("Change App PIN").setView(box)
            .setNegativeButton("Cancel", null).setPositiveButton("Update", null).create()
        dialog.setOnShowListener {
            dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener {
                val oldPin = current.text.toString()
                val newPin = next.text.toString()
                if (pinHash(oldPin) != prefs.getString("pin_hash", null)) {
                    current.error = "Current PIN galat hai"
                } else if (newPin.length !in 4..6 || newPin.any { !it.isDigit() }) {
                    next.error = "PIN 4 se 6 digits ka hona chahiye"
                } else {
                    prefs.edit().putString("pin_hash", pinHash(newPin)).apply()
                    dialog.dismiss()
                    toast("PIN updated")
                }
            }
        }
        dialog.show()
    }

    private fun makeBackup(): JSONObject {
        val arr = JSONArray()
        db.all().forEach { f ->
            val obj = JSONObject().put("id", f.id).put("model", f.model).put("size", f.size)
                .put("amount", f.amount).put("dateTime", f.dateTime)
            if (f.photo.isNotBlank() && File(f.photo).exists()) {
                val bytes = File(f.photo).readBytes()
                obj.put("photoName", File(f.photo).name).put("photoBase64", Base64.encodeToString(bytes, Base64.NO_WRAP))
            }
            arr.put(obj)
        }
        return JSONObject().put("app", "FurnitureHisab").put("version", 1).put("items", arr)
    }
    private fun restoreBackup(data: JSONObject) {
        val arr = data.getJSONArray("items")
        db.clear()
        for (i in 0 until arr.length()) {
            val o = arr.getJSONObject(i)
            var photo = ""
            if (o.has("photoBase64")) {
                val name = o.optString("photoName", "restored_$i.jpg").replace(Regex("[^A-Za-z0-9._-]"), "_")
                val file = File(filesDir, name)
                file.writeBytes(Base64.decode(o.getString("photoBase64"), Base64.DEFAULT))
                photo = file.absolutePath
            }
            db.save(null, o.optString("model"), o.optString("size"), o.optDouble("amount"),
                o.optString("dateTime"), photo)
        }
    }
    private fun money(v: Double) = String.format(Locale("en", "IN"), "%,.2f", v)
    private fun lp(w: Int, h: Int, bottom: Int = 0) = LinearLayout.LayoutParams(w, h).apply { if (bottom > 0) bottomMargin = bottom }
    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_SHORT).show()
}
